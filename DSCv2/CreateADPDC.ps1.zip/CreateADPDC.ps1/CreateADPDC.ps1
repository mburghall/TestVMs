﻿configuration CreateADPDC
{
   param
   (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    )

    Import-DscResource -ModuleName xActiveDirectory, xStorage, xNetworking, PSDesiredStateConfiguration, xPendingReboot
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    $Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)

    Node localhost
    {
        LocalConfigurationManager
        {
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyOnly'            
            RebootNodeIfNeeded = $true            
        }

	WindowsFeature RSAT
	{
	   Ensure = "Present"
	   Name = "RSAT"
	}

        WindowsFeature ADDSInstall 
	{ 
	   Ensure = "Present" 
	   Name = "AD-Domain-Services"
	}
	
	xWaitForADDomain DscForestWait 
	{ 
	   DomainName = $DomainName 
	   DomainUserCredential= $DomainCreds
	   RetryCount = $RetryCount
	   RetryIntervalSec = $RetryIntervalSec
	   DependsOn = "[WindowsFeature]ADDSInstall"
	}
      
	xADDomainController ReplicaDC 
	{ 
	   DomainName = $DomainName 
	   DomainAdministratorCredential = $DomainCreds 
	   SafemodeAdministratorPassword = $SafeModeAdminCreds
	   DatabasePath = "C:\NTDS"
	   LogPath = "C:\NTDS"
	   SysvolPath = "C:\SYSVOL"
	   DependsOn = "[xWaitForADDomain]DScForestWait"
	}

	Registry RestrictRPCPort
	{
    	    Ensure = "Present"
            Key = "HKLM:\SYSTEM\CurrentControlSet\Services\NTDS\Parameters"
            ValueName = "TCP/IP Port"
            ValueData = "3030"
            ValueType = "REG_DWORD"
	    DependsOn = "[xADDomainController]ReplicaDC"
	}

	Registry RestrictRPCPortNet
	{
    	    Ensure = "Present"
            Key = "HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters"
            ValueName = "DCTcpipPort"
            ValueData = "3030"
            ValueType = "REG_DWORD"
	    DependsOn = "[Registry]RestrictRPCPort"
	}

	xPendingReboot Reboot1
	{ 
	   Name = "RebootServer"
	   DependsOn = "[Registry]RestrictRPCPortNet"
	}	
   }
}